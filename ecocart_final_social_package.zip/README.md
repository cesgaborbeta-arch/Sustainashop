# 🌿 EcoCart: Shop Smart

![EcoCart Logo](ecocart_logo.png)

A modern, minimalist **Filipino eco-shopping website** promoting sustainable and affordable locally made products.  
Built to inspire responsible consumption and highlight eco-friendly craftsmanship in the Philippines 🇵🇭.

## 🛍️ Featured Products
| Product | Description | Price |
|:--|:--|:--|
| 👕 **Organic Cotton T-Shirt** | Locally made using 100% organic cotton, biodegradable fabric, and low-impact dyes. | ₱399 |
| 👟 **Eco-Friendly Shoes** | Made from recycled rubber and pineapple fiber (Piñatex). Lightweight and stylish. | ₱699 |
| 🧼 **Natural Bar Soap** | Handmade with coconut oil and plant-based ingredients. Plastic-free packaging. | ₱99 |
| 🪥 **Bamboo Toothbrush** | Biodegradable bamboo handle, soft plant-based bristles, eco-packaged. | ₱79 |
| 👜 **Reusable Tote Bag** | Locally woven from abaca and cotton blend. Perfect for daily eco-shopping. | ₱149 |

🌿 *Proudly supporting Filipino-made sustainable goods.*

---

## 🧭 About EcoCart
**EcoCart** helps Filipinos shop sustainably with affordable, eco-friendly products from local brands.  
Every product you see supports ethical production, waste reduction, and a greener lifestyle.

---

## ✉️ Contact
💬 *Order or inquire via [EcoCartPH@gmail.com](mailto:EcoCartPH@gmail.com)*  
🌐 *Follow us on Instagram [@EcoCartPH](https://instagram.com/EcoCartPH)*

---

## 🪪 QR Code
Scan the QR below to visit the live site:

![EcoCart QR Code](ecocart_qr.png)

---

## 🌐 Live Site
👉 **[https://gabrielleorbeta.github.io/ecocart](https://gabrielleorbeta.github.io/ecocart)**

---

## 🌱 Social Preview
The repository includes a `social_preview.png` file optimized for social sharing.

---

### 💻 Tech Stack
- HTML5 + CSS3 (Responsive)
- Minimalist pastel design
- Local image assets (PH-made eco products)
- Hosted on GitHub Pages

© 2025 EcoCart PH — *Shop Smart. Live Green.*
